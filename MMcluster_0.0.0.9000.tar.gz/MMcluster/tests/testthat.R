library(testthat)
library(MMcluster)

test_check("MMcluster")
